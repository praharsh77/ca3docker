<?php 

$conn= new mysqli('ca-mysql-app','praharshkumarsingh','11902509','ca_db')or die("Could not connect to mysql".mysqli_error($con));
